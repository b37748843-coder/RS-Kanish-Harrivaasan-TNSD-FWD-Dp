// Typing Effect
const text = "Kanish Harrivaasan";
let index = 0;

function typeEffect() {
  if (index < text.length) {
    document.querySelector(".typing").textContent += text.charAt(index);
    index++;
    setTimeout(typeEffect, 150);
  }
}

window.onload = typeEffect;